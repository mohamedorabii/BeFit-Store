<?php

return [

    'label' => 'Zakładki',

];
