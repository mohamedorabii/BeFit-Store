<?php

return [

    'label' => 'Välilehdet',

];
