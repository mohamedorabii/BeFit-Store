<?php

return [

    'label' => 'Sekmeler',

];
