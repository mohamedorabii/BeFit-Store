<?php

return [

    'label' => 'Pestañas',

];
