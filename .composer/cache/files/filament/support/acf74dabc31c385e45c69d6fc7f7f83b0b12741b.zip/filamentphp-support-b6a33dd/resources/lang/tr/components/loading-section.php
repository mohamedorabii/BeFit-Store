<?php

return [

    'label' => 'Yükleniyor...',

];
