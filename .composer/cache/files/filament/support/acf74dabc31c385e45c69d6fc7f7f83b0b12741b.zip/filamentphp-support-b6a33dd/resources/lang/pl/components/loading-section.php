<?php

return [

    'label' => 'Ładowanie...',

];
