import '@fontsource-variable/inter'
