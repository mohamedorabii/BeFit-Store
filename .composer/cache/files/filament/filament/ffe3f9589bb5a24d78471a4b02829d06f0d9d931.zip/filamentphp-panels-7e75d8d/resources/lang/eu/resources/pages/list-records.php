<?php

return [

    'breadcrumb' => 'Zerrenda',

];
