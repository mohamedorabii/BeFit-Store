<?php

return [

    'breadcrumb' => 'ዘርዝር',

];
